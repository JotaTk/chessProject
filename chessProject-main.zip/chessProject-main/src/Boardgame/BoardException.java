package Boardgame;

public class BoardException extends RuntimeException {
    public BoardException(String msg) {
        super(msg);
    }
}


