package Chess;

public enum Color {
    BLACK,
    WHITE,
}
